# 🚀 프로젝트: 개인 포트폴리오 & 블로그 (최종 완성본)

Next.js, Zustand, Supabase를 활용한 관리자 친화형 포트폴리오 사이트입니다.

---

## 1. 추가 핵심 기능 (Admin & Social)

- **관리자 대시보드**: 게시글 수, 카테고리별 통계, 최근 댓글 등을 한눈에 확인.
- **프로필 관리**: 설정 페이지에서 사진(Avatar)과 소개글 실시간 변경.
- **대댓글 (Nested Comments)**: 댓글에 대한 답글 기능 추가.
- **관리자 특권**: 관리자 로그인 시 모든 댓글에 '관리자' 배지가 붙으며 삭제 권한 가짐.

---

## 2. 사이트맵 (Sitemap)

### 🌐 User Side (공개)

- `/` : **Home** (관리자 프로필 + 최신글 리스트)
- `/works` : **Portfolio** (프로젝트 위주)
- `/life` : **Daily** (음식/그림 - 카카오지도 포함)
- `/posts/[id]` : **Detail** (본문 + 지도 + **대댓글 지원 댓글창**)

### 🔐 Admin Side (비공개 - Middleware 보호)

- `/admin` : **Dashboard** (전체 통계 및 게시글/댓글 요약 관리)
- `/admin/write` : **Editor** (새 글 작성 및 위치 정보 설정)
- `/admin/edit/[id]` : **Editor** (기존 글 수정/삭제)
- `/admin/settings` : **Profile Setting** (내 사진, 소개, 계정 관리)

---

## 3. 데이터베이스 설계 (ERD)

### Table: `posts` (게시글)

- 기존 구성과 동일 (카카오지도 좌표 `lat`, `lng` 포함)

### Table: `profiles` (관리자 설정)

| Column       | Type      | Description        |
| :----------- | :-------- | :----------------- |
| `id`         | uuid (PK) | auth.users 참조    |
| `avatar_url` | text      | 관리자 프로필 사진 |
| `username`   | text      | 닉네임             |
| `bio`        | text      | 자기소개 문구      |

### Table: `comments` (댓글 & 대댓글 통합)

| Column          | Type      | Description                                                      |
| :-------------- | :-------- | :--------------------------------------------------------------- |
| `id`            | uuid (PK) | 댓글 ID                                                          |
| `post_id`       | uuid (FK) | 게시글 연결                                                      |
| **`parent_id`** | uuid (FK) | **대댓글용 (이 값이 null이면 댓글, 값이 있으면 해당 ID의 답글)** |
| `content`       | text      | 내용                                                             |
| `nickname`      | text      | 작성자 (비로그인/관리자)                                         |
| `password`      | text      | 비로그인용 삭제 비밀번호                                         |
| `is_admin`      | boolean   | 관리자 작성 여부                                                 |

---

## 4. 핵심 구현 로직 가이드

### 📊 관리자 대시보드 (Dashboard)

- **Supabase Query**: `select('*', { count: 'exact' })`를 사용하여 총 게시글 수와 카테고리별 개수를 가져와 Zustand에 저장 후 차트나 카드로 시각화합니다.

### 💬 대댓글 (Thread) 구현 방식

1. **데이터 구조**: `parent_id` 컬럼을 활용합니다.
2. **UI 렌더링**:
   - `comments` 배열에서 `parent_id`가 없는 것들을 먼저 렌더링합니다.
   - 각 댓글 아래에 `parent_id === comment.id`인 것들을 들여쓰기해서 보여줍니다.
3. **관리자 로그인 시**: 댓글 입력창에 자동으로 내 프로필 정보가 세팅되며 `is_admin: true`로 저장됩니다.

### 📍 카카오지도 API 연동

- **Editor**: 주소 검색 후 마커 위치의 좌표를 DB에 저장.
- **View**: 저장된 `lat`, `lng`로 지도 생성. (입문자라면 `react-kakao-maps-sdk` 라이브러리 사용을 강력 추천합니다.)

---

## 5. 보안 및 권한 (RLS & Middleware)

- **Admin 페이지**: `middleware.ts`에서 Supabase 세션이 없으면 `/admin` 진입 시 로그인 페이지로 강제 이동.
- **댓글 삭제**:
  - `is_admin`이 true이면 로그인 세션 체크 후 즉시 삭제.
  - 비로그인 유저라면 사용자가 입력한 `password`와 DB의 값을 비교하여 처리.
